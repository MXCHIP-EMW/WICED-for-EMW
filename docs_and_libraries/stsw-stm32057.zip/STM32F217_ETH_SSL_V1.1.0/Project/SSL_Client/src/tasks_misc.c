/**
  ******************************************************************************
  * @file    tasks_misc.c
  * @author  MCD Application Team
  * @version V1.1.0
  * @date    07-October-2011
  * @brief   Task functions body.
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************  
  */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/**
  * @brief  Toggle LED4 every 200ms .
  * @param  pvParameters not used
  * @retval None
  */
void ToggleLed(void * pvParameters)
{
  portTickType xLastWakeTime;
  const portTickType xFrequency = 200;

  /* Initialise the xLastWakeTime variable with the current time*/
  xLastWakeTime = xTaskGetTickCount();

  /* Infinite loop */ 
  for( ;; )
  {
    STM_EVAL_LEDToggle(LED4); 
    /* Wait for the next cycle */
    vTaskDelayUntil(&xLastWakeTime, xFrequency);
  } 
}

/**
  * @brief  Lists all the current tasks and their status.
  * @param  pvParameters not used
  * @retval None
  */
void TraceFile(void *pvParameters)
{
  signed char  Buffer[120]; 

  /* Infinite loop */ 
  for ( ;; )
  {
    /* Insert 800 ms delay */    
    vTaskDelay(800);
      
    /* Lists the current tasks */
    vTaskList(Buffer);

    /* List of tasks and their status */
    printf("%s\n\r", "The current tasks and their status :");
    printf("%s\n\r", "B : Blocked, R : Ready, D : Deleted, S : Suspended");
    printf("%s\n\r", "---------------------------------------------"); 
    printf("%s\n\r", "Name          State  Priority  Stack   Num" );
    printf("%s\n", "---------------------------------------------"); 
    printf("%s",Buffer);
    printf("%s\n\r", "                                             "); 
    printf("%s\n\r", "                                             "); 
    printf("%s\n\r", "                                             "); 

    /* Insert 600 ms delay */
    vTaskDelay(600);
  }
}
/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
