#ifndef __MAIN_H
#define __MAIN_H

#define APP_INFO          "mxchipWNet Demo: Web server and OTA"


#endif /* __MAIN_H */
