/**
  @page AN3430 AN3430 SPI Master Non Optimized project Readme file
 
  @verbatim
  ******************** (C) COPYRIGHT 2011 STMicroelectronics *******************
  * @file    readme.txt
  * @author  MCD Application Team
  * @version V1.0.0
  * @date    19-August-2011
  * @brief   This is the readme file of the AN3430: How to achieve the lowest 
  *          current consumption with STM32F2xx/SPI Master non optimized project.
  ******************************************************************************
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
  * AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
  * INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
  * CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
  * INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  ******************************************************************************
  @endverbatim
 
 @par Description

This directory contains a set of sources files and pre-configured projects that 
build the SPI master non optimized porgram.

This project is used in the AN3430 as an SPI master non optimized project which 
communicate with other STM32F2 SPI slave, This project is used and modified as 
described on the AN3430 (from step1 to step10) to achieve the lowest current 
consumption.

@par Directory contents 

  - Project/SPI_MASTER_NonOptimized/system_stm32f2xx.c   STM32F2xx system clock configuration file
  - Project/SPI_MASTER_NonOptimized/stm32f2xx_conf.h     Library Configuration file
  - Project/SPI_MASTER_NonOptimized/stm32f2xx_it.h       Interrupt handlers header file
  - Project/SPI_MASTER_NonOptimized/stm32f2xx_it.c       Interrupt handlers
  - Project/SPI_MASTER_NonOptimized/main.c               Main program

@par Hardware and Software environment

  - This example runs on STM32F2xxx Devices.
  
  - This example has been tested with a board which only contains the MCU,
   boot pins (VDD,VSS) and decoupling capacitors (refer to AN3430 Appendix A: Schematics).

@par How to use it ? 

In order to make the program work, you must do the following:

 - Open your preferred toolchain 
 - Rebuild all files and load your image into target memory
 - Run the example 

 @note For more details about this project, please refer to AN3430.
 
 * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
 */
