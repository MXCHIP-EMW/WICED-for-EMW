var structos_message_q_def__t =
[
    [ "item_sz", "structos_message_q_def__t.html#a4c2a0c691de3365c00ecd22d8102811f", null ],
    [ "pool", "structos_message_q_def__t.html#a269c3935f8bc66db70bccdd02cb05e3c", null ],
    [ "queue_sz", "structos_message_q_def__t.html#a8a83a3a8c0aa8057b13807d2a54077e0", null ]
];